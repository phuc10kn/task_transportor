# Sync Engine — Từ CIS lên Jira/Backlog

## Nguyên tắc

1. **Idempotent**: Sync cùng dữ liệu nhiều lần không tạo duplicate.
2. **Transactional**: Mỗi sync là một transaction — nếu fail, rollback state.
3. **Retry**: Tự động retry 3 lần, sau đó đưa vào failed queue.
4. **Audit**: Mọi sync đều ghi sync_journal.

---

## Components

```
┌─────────────────────────────┐
│      Sync Engine            │
│                             │
│  ┌─────────────────────┐   │
│  │  Sync Scheduler     │   │  ← Poll issues có status = 'approved'/'update_pending'
│  └──────────┬──────────┘   │
│             │              │
│  ┌──────────▼──────────┐   │
│  │  Conflict Detector  │   │  ← Kiểm tra conflict trước khi sync
│  └──────────┬──────────┘   │
│             │              │
│  ┌──────────▼──────────┐   │
│  │  API Gateway        │   │  ← Gọi Backlog API / Jira API
│  └──────────┬──────────┘   │
│             │              │
│  ┌──────────▼──────────┐   │
│  │  State Updater      │   │  ← Cập nhật CIS sau sync
│  └──────────┬──────────┘   │
│             │              │
│  ┌──────────▼──────────┐   │
│  │  Retry Handler      │   │  ← Retry queue
│  └─────────────────────┘   │
└─────────────────────────────┘
```

---

## Sync scheduler

```
Poll every N seconds:
  SELECT * FROM issues
  WHERE status IN ('approved', 'update_pending')
    AND project_id IN (SELECT id FROM projects WHERE sync_enabled = 1)
  ORDER BY updated_at ASC
  LIMIT 50

Với mỗi issue:
  1. direction = ?
     - Nếu issue.source = 'backlog' AND issue.status = 'approved' → 'cis_to_jira' (tạo mới)
     - Nếu issue.source = 'backlog' AND issue.status = 'update_pending' → 'cis_to_jira' (cập nhật)
     - Nếu issue.source = 'jira' AND issue.sync_direction = 'bidirectional' → 'cis_to_backlog'
  2. Gọi Conflict Detector
  3. Build payload
  4. Gọi API
  5. Cập nhật state
```

---

## Conflict detection

Conflict xảy ra khi cả Backlog và Jira cùng thay đổi một field giữa hai lần sync.

```
Trước khi sync, kiểm tra:

  fields_json['status'] = {
    "backlog": "Resolved",       ← Khách hàng đã đóng issue
    "jira": "In Progress",       ← Dev đang làm
    "jira_updated_at": "2026-06-23T10:00:00",
    "backlog_updated_at": "2026-06-23T09:00:00"
  }
  
  → CONFLICT: status thay đổi ở cả 2 phía
  → Resolution strategy:
      1. "jira_wins": Status từ Jira được giữ (vì Jira là nơi làm việc chính)
      2. "last_writer_wins": Phía cập nhật sau cùng thắng
      3. "manual": Không sync, đưa vào conflict queue chờ người xử lý
```

**Config per project**:
```json
{
  "conflict_resolution": {
    "status": "jira_wins",
    "assignee": "jira_wins",
    "priority": "backlog_wins",
    "default": "manual"
  }
}
```

**Khi conflict xảy ra**:
```
1. issues.status = 'conflict'
2. sync_journal: action = 'status_change', status = 'failed', error = 'Conflict detected'
3. anomaly_log: type = 'unusual_field_change', severity = 'warning'
4. Notification đến admin
```

---

## API Gateway — Retry & Error handling

```
Call API:
  ├── Success → status = 'success'
  ├── 429 Too Many Requests
  │   └── Exponential backoff: 1s → 2s → 4s → 8s → max 60s
  ├── 4xx (bad request)
  │   └── Không retry → status = 'failed', error = response body
  │   └── anomaly_log: severity = 'critical', cần người xử lý
  └── 5xx (server error)
      └── Retry 3 lần với backoff
      └── Sau 3 lần → failed queue
```

**Failed queue**:
```sql
-- Sync journal với status = 'failed' và retry_count < 3
SELECT * FROM sync_journal
WHERE status = 'failed' AND retry_count < 3
ORDER BY created_at ASC

-- Retry job chạy mỗi 5 phút
UPDATE issues SET status = 'approved' WHERE id IN (
  SELECT issue_id FROM sync_journal
  WHERE status = 'failed' AND retry_count < 3
  GROUP BY issue_id
  HAVING MAX(created_at) < datetime('now', '-5 minutes')
)
```

---

## Sync comment

```
Với mỗi issue_comments có sync_status = 'pending':

  1. Xác định hướng:
     - source = 'backlog' AND content_translated ≠ NULL → sync lên Jira
     - source = 'jira' AND content_translated ≠ NULL → sync lên Backlog
     - source = 'backlog' AND content_translated = NULL → chưa dịch, skip

  2. Gọi API:
     - Jira: POST /rest/api/3/issue/WEC1-789/comment
     - Backlog: POST /api/v2/issues/ONE_KYORITSU-123/comments

  3. Cập nhật:
     - issue_comments.sync_status = 'synced'
     - issue_comments.jira_comment_id / backlog_comment_id

  4. sync_journal: direction_from = 'cis', direction_to = 'jira' | 'backlog', action = 'comment_added', status = 'success'
```

---

## Batch sync

Khi có nhiều issue pending cùng lúc:

```
1. Collect tối đa 50 issue
2. Group by project (mỗi project có Jira/Backlog khác nhau)
3. Sort by priority:
   - Ưu tiên create trước update (issue mới cần tạo trước)
   - Ưu tiên issue có translation đã review lâu nhất
4. Sync từng cái (không batch API — mỗi issue một request)
5. Nếu một issue fail → các issue khác vẫn tiếp tục
```

---

## Sync Journal — Sau mỗi lần sync

```json
{
  "issue_id": "uuid-xxx",
  "project_id": "wecsy-main",
  "direction_from": "cis",
  "direction_to": "jira",
  "action": "create",
  "status": "success",
  "field_name": null,
  "old_value": null,
  "new_value": "WEC1-789",
  "trigger": "auto",
  "created_at": "2026-06-23T10:00:01"
}
```

Dùng để:
- Trace lịch sử của một issue
- Tính số lượng sync thành công / thất bại
- Phát hiện failure chain (5+ failures liên tiếp → anomaly)
- Dashboard thống kê
thống kê
