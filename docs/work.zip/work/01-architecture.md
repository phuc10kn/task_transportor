# Architecture — Central Sync Hub

## Tổng quan

Hub trung gian thay thế mô hình "Codex gọi từng lệnh CLI" hiện tại bằng một **Central Issue Store (CIS)** làm single source of truth, với AI xử lý ở giữa.

```
  ┌──────────┐    ┌──────────┐
  │ Backlog  │    │  Jira    │
  │ (Nguồn)  │    │ (Chính)  │
  └────┬─────┘    └────┬─────┘
       │               │
       ▼               ▼
  ┌─────────────────────────────────────┐
  │         Webhook Layer               │
  │  (Backlog Webhook + Jira Webhook)   │
  └──────────────┬──────────────────────┘
                 │
                 ▼
  ┌─────────────────────────────────────┐
  │         Central Issue Store         │
  │  ┌────────┐ ┌────────┐ ┌─────────┐ │
  │  │ issues │ │ queue  │ │ journal │ │
  │  └────────┘ └────────┘ └─────────┘ │
  │  ┌────────┐ ┌────────┐             │
  │  │ rules  │ │ drafts │             │
  │  └────────┘ └────────┘             │
  └──────────────┬──────────────────────┘
                 │
        ┌────────┴────────┐
        ▼                 ▼
  ┌──────────┐    ┌──────────┐
  │ AI Layer │    │ Manual   │
  │ translate│    │ review   │
  │ suggest  │    │ approve  │
  │ detect   │    │ override  │
  └──────────┘    └──────────┘
```

## Nguyên tắc

1. **Jira là nơi làm việc chính** — Dev thao tác trên Jira. Backlog là nguồn yêu cầu từ khách hàng.
2. **Mọi thứ qua CIS** — Backlog và Jira không nói chuyện trực tiếp. CIS là trung gian duy nhất.
3. **Nội dung gốc bất biến** — Backlog content (tiếng Nhật) giữ nguyên trong CIS. Bản dịch là field riêng.
4. **Sync không phá dữ liệu** — Mỗi lần sync là một transaction. Rollback được nếu fail.
5. **AI propose, human decide** — AI dịch, suggest mapping, detect bất thường. Quyết định cuối cùng thuộc về người dùng.

## 4 luồng chính

| Luồng | Hướng | Trigger | Mô tả |
|-------|-------|---------|-------|
| Backlog → CIS | Inbound | Webhook | Issue mới hoặc cập nhật từ khách hàng Nhật |
| CIS → Jira | Outbound | AI review done | Issue đã dịch + duyệt → push lên Jira |
| Jira → CIS | Inbound | Webhook | Dev thay đổi status, comment, field |
| CIS → Backlog | Outbound | Manual hoặc rule | Khi cần thông báo cho khách hàng |

## So sánh với thiết kế hiện tại

| Khía cạnh | Hiện tại (backlog2jira) | Hub trung gian |
|-----------|------------------------|----------------|
| Hướng | Một chiều B → J | Hai chiều B ↔ J |
| Xử lý | CLI + Codex thủ công | Webhook auto + AI + review |
| State | Mapping log (4 tables) | Issue store (full content) |
| Translation | Trong đầu Codex | CIS giữ bản gốc + bản dịch + review trail |
| Mapping | Config tĩnh | Học dần từ dữ liệu |
| Safety | Guardrails trong CLI | Anomaly detection + approval queue |
